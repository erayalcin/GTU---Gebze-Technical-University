import cse222_hw1.*;

import java.util.Scanner;
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		System.out.println("------------------- Testing with ArrayList -------------------");
		TestArrayList test1=new TestArrayList();
		StreetArrayList testDriver= new StreetArrayList(60);
		testDriver.firstFillArrayList();
		test1.houseTest(testDriver);
		test1.officeTest(testDriver);
		test1.marketTest(testDriver);
		test1.playgroundTest(testDriver);
		test1.displayTest(testDriver);
		test1.occupiedPositionTest(testDriver);
		System.out.println("------------------- Testing with LinkedList -------------------");
		TestLinkedList test2=new TestLinkedList();
		StreetLinkedList testDriver1= new StreetLinkedList(60);
		testDriver1.firstFillArrayList();
		test2.houseTest(testDriver1);
		test2.officeTest(testDriver1);
		test2.marketTest(testDriver1);
		test2.playgroundTest(testDriver1);
		test2.displayTest(testDriver1);
		test2.occupiedPositionTest(testDriver1);
		
		System.out.println("------------------- Testing with LDLinkedList -------------------");
		TestLDLinkedList test3=new TestLDLinkedList();
		StreetLDLinkedList testDriver2= new StreetLDLinkedList(60);
		testDriver2.firstFillArrayList();
		test3.houseTest(testDriver2);
		test3.officeTest(testDriver2);
		test3.marketTest(testDriver2);
		test3.playgroundTest(testDriver2);
		test3.displayTest(testDriver2);
		test3.occupiedPositionTest(testDriver2);
		mainMenu();
		
		
	}
	 public static void mainMenu()
	    {
		 	
			int len;
			System.out.print("\nPlease enter the length of streeet : ");
			Scanner scanner = new Scanner(System.in);
			len = scanner.nextInt();
			StreetArrayList street= new StreetArrayList(len);
			street.firstFillArrayList();
		 	int choice=0;
		 	while(choice != -1)
	        {
		 		System.out.println("(1) Editing mode");
	            System.out.println("(2) Viewing mode");
	            System.out.print ("Choice :  ");
	            choice = scanner.nextInt();
	            switch(choice)
	            {
	                case 1:
	                	int edit_choice=0;
	        	        
	        	        while(edit_choice != -1)
	        	        {
	        	        	System.out.println("\n");
	        	            System.out.println("(1) Add a house");
	        	            System.out.println("(2) Add an office");
	        	            System.out.println("(3) Add a market");
	        	            System.out.println("(4) Add a playground");
	        	            System.out.println("(5) Remove a building");
	        	            System.out.println("(-1) Exit\n");
	        	            System.out.print ("Choice : ");
	        	            edit_choice = scanner.nextInt();
	        	            switch(edit_choice)
	        	            {
	        	                case 1:
	        	                	int houseLength,houseHeight,housePosition,houseRooms,streetNumber;
	        	                	String houseColor,houseOwner;
	        	                	System.out.print("Enter the length,heigth,position, number of room, color and owner of house    :");
	        	                	try {
	        	                		houseLength = scanner.nextInt();
		        	                	houseHeight = scanner.nextInt();
		        	                	
		        	                	housePosition = scanner.nextInt();
		        	                	houseRooms = scanner.nextInt();
		        	                	houseColor = scanner.next();
		        	                	houseOwner = scanner.next();
		        	                	Houses house1=new Houses(houseColor,houseOwner,houseRooms,houseLength,houseHeight,housePosition,1);
		        	                	if(street.setBuildHouse(house1)==true)
		        	                	{
		        	                		System.out.println("\nAdded.");
		        	                	}
		        	                	else System.out.println("\nNot added. Position is full");
	        	            		
	        	                	}
	        	            		catch(Exception e){
	        	            			System.out.println("You entered the wrong entry.....  ");	
	        	            			System.exit(0);
	        	            		}
	        	                	
	        	                	
	        	                    break;
	        	                case 2:
	        	                	int officeLength,officeHeight,officePosition;
	        	                	String jobType,officeOwner;
	        	                	System.out.print("Enter the length,heigth,position, job type and owner of office    			:");
	        	                	try {
	        	                	officeLength = scanner.nextInt();
	        	                	officeHeight = scanner.nextInt();
	        	                	
	        	                	officePosition = scanner.nextInt();
	        	                	jobType = scanner.next();
	        	                	officeOwner = scanner.next();
	        	                	
	        	                	Offices office1=new Offices(jobType,officeOwner,officeLength,officeHeight,officePosition,1);
	        	                	if(street.setBuildOffice(office1)==true)
	        	                	{
	        	                		System.out.println("\nAdded.");
	        	                	}
	        	                	else System.out.println("\nNot added. Position is full");
	        	                	}
	        	                	catch(Exception e){
	        	            			System.out.println("You entered the wrong entry.....  ");	
	        	            			System.exit(0);
	        	            		}
	        	                    break;
	        	                    
	        	                case 3:
	        	                	int marketLength,marketHeight,marketPosition;
	        	                	String openTime,closeTime,ownerMarket;
	        	                	System.out.print("Enter the length,heigth,position, opening time,closing time and owner of market    			:");
	        	                	try {
	        	                	marketLength = scanner.nextInt();
	        	                	marketHeight = scanner.nextInt();
	        	                	
	        	                	marketPosition = scanner.nextInt();
	        	                	openTime = scanner.next();
	        	                	closeTime = scanner.next();
	        	                	ownerMarket = scanner.next();
	        	                	
	        	                	Markets market1=new Markets(openTime,closeTime,ownerMarket,marketLength,marketHeight,marketPosition,1);
	        	                	if(street.setBuildMarket(market1)==true)
	        	                	{
	        	                		System.out.println("\nAdded.");
	        	                	}
	        	                	else System.out.println("\nNot added. Position is full");
	        	                	}
	        	                	catch(Exception e){
	        	            			System.out.println("You entered the wrong entry.....  ");	
	        	            			System.exit(0);
	        	            		}
	        	                    break; 
	        	                case 4:
	        	                	try {
	        	                    int positionPlayground,lengthPlayground,streetPlayground;
	        	                    System.out.print("Enter the length,position of playground    			:");
	        	                    lengthPlayground = scanner.nextInt();
	        	                    streetPlayground = scanner.nextInt();
	        	                    positionPlayground = scanner.nextInt();
	        	                	Playgrounds play1=new Playgrounds(lengthPlayground,10,positionPlayground,streetPlayground);
	        	                	if(street.setBuildPlayground(play1)==true)
	        	                	{
	        	                		System.out.println("\nAdded.");
	        	                	}
	        	                	else System.out.println("\nNot added. Position is full");
	        	                	}
	        	                    catch(Exception e){
	        	                    	System.out.println("You entered the wrong entry.....  ");	
	        	            			System.exit(0);
	        	                    }
	        	                    
	        	                    break;
	        	                case 5:
	        	                   street.showBuildings();
	        	                   int position,streetNum;
	        	                   System.out.print("\nSelect   position to remove building  :");
	        	                   try {
	        	                   
	        	                   position=scanner.nextInt();
	        	                   street.removeBuild(1,position);
	        	                   }
	        	                   catch(Exception e){
	        	            			System.out.println("You entered the wrong entry.....  ");	
	        	            			System.exit(0);
	        	            		}
	        	                    break;
	        	               
	        	               
	        	                case -1:
	        	                    System.out.println("Exiting...");
	        	                    break;
	        	                default:
	        	                    System.out.println("Wrong choice! Try again!");
	        	                    break;
	        	            }
	        	        }
	                    break;
	                case 2:
	                	int view_choice=0;
	        	        
	        	        while(view_choice != -1)
	        	        {
	        	        	System.out.println("\n");
	        	            System.out.println("(1) Display the total remaining length of lands on the street.");
	        	            System.out.println("(2) Display the list of buildings on the street.");
	        	            System.out.println("(3) Display the number and ratio of length of playgrounds in the street.");
	        	            System.out.println("(4) Calculate the total length of street occupied by the markets, houses or offices.");
	        	            System.out.println("(5) Display the skyline silhouette of the street");
	        	            System.out.println("(-1) Exit\n");
	        	            System.out.print ("Choice : ");
	        	            view_choice = scanner.nextInt();
	        	            
	        	            switch(view_choice)
	        	            {
	        	                case 1:
	        	                	int remaining=street.remainingLand();
	        	                    System.out.println("Total remaining length of land on street : "+remaining);
	        	                    break;
	        	                case 2:
	        	                	street.showBuildings();
	        	                    break;
	        	                case 3:
	        	                	double result;
	        	                	result=street.ratioPlayground();
	        	                	System.out.println("The number and ratio of length of playgrounds in the street   :  "+result);
	        	                    break;
	        	                case 4:
	        	                	System.out.println("Total length of street occupied by the markets, houses or offices : "+street.occupiedBuildings());
	        	                    break;
	        	                case 5:
	        	                	street.showSiulette();
	        	                    break;
	        	                case -1:
	        	                    System.out.println("Exiting...");
	        	                    break;
	        	                default:
	        	                    System.out.println("Wrong choice! Try again!");
	        	                    break;
	        	            }
	        	        }
	                    break;
	                
	                case -1:
	                    System.out.println("Exiting...");
	                    break;
	                default:
	                    System.out.println("Wrong choice! Try again!");
	                    break;
	            }
	        }
	        
	    }
	

}
