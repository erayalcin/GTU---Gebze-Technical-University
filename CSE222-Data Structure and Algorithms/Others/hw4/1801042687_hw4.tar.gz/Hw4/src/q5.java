public class q5 {
	/**
	 * @arr array
	 * @index array's index
	 * @blockNum number of blocks to add
	 */
	
	static public void fillArray(int arr[],int index,int blockNum)
	{
		
			
		/**
		 * Base Case
		 */
		
		if(index+blockNum>arr.length || blockNum>arr.length)
		{
			return;
		}
		/**
		 * Recursive Case 
		 * The length of the block to be added and the index should not exceed the length of the array.
		 */
		if(index+blockNum<=arr.length)
		{
			
			for(int i=0;i<blockNum;i++)
			{
				arr[index+i]=1;
			}
			for(int i=0;i<arr.length;i++)
			{
				System.out.print(arr[i]);
			}
			System.out.println();
			
			fillArray(arr,index+1+blockNum,blockNum);
			
		}
		/**
		 * Array cleaning
		 */
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=0;
		}
		

	
		
		
	}
	

}