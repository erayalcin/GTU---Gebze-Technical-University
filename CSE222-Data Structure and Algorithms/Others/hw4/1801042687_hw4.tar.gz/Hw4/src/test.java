
public class test {


	public static void testDriver()
	{
		System.out.println("--------------TESTING QUESTION 1 ----------------");
		String str1 = "erayalcin123computer",
		str2 = "com";
		System.out.println("Index :"+q1.countSubstrig(str1,str2,0));
		
		String str3 = "denemedeneme123eraydenemeeray",
		str4 = "eray";
		System.out.println("Index :"+q1.countSubstrig(str3,str4,0));
		
				
		System.out.println("--------------TESTING QUESTION 2 ----------------");		
		int array[]={-15,-7,-6,-3,-1,0,1,2,3,4,5,6,7,8,9,10};
		System.out.println("Count  :"+q2.findCountElements(array,0,-7,10,0));
		
		
		int array1[]={-15,-7,-6,-3,-1,0,1,2,3,4,5,6,7,8,9,10};
		System.out.println("Count  :"+q2.findCountElements(array1,0,5,8,0));

		
		int array2[]={-15,-7,-6,-3,-1,0,1,2,3,4,5,6,7,8,9,10};
		System.out.println("Count  :"+q2.findCountElements(array2,0,-2,6,0));
		System.out.println("--------------TESTING QUESTION 3 ----------------");
		int target=5;
		int []arr = {0,1, 2, 3,4,5,6};
		q3.printSubArrays(arr, 0, 0,target);
		System.out.println();
		int target1=7;
		int []arr1 = {0,2, 1, 3,4};
		q3.printSubArrays(arr1, 0, 0,target1);
		System.out.println();
		int target2=3;
		int []arr2 = {2,1,3,4,0};
		q3.printSubArrays(arr2, 0, 0,target2);
		System.out.println();
		
		
		
		System.out.println("\n--------------TESTING QUESTION 5 ----------------");
		
		
		int array3[]={0,0,0,0,0,0,0,0,0,0};
		for(int i=3;i<=array.length;i++)
		{
			q5.fillArray(array3,0,i);
		}
	}
	public static void main(String[] args) {
		testDriver();
		
	
	}

}
