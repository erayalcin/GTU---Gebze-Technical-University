
public class q2 {

	/**
	 * @arr array
	 * @index array's index
	 * @n1 Values range
	 * @n2 Values Range
	 * @count number of items between n1 and n2
	 */
	
	
	static int  findCountElements(int arr[],int index,int n1,int n2,int count)
	{
		/**
		 * Base Case
		 */
		if(arr.length < index || index < 0)
		{
			return -1;
		}
		/**
		 * Recursive Case
		 */
		if(arr[index]==n1 || (arr[index]<n1 && arr[index+1]>n1)) return findCountElements(arr,index+1,n1,n2,0);
		
		if(arr[index]==n2) return count;
		
		return findCountElements(arr,index+1,n1,n2,count+1);
			
	}
	

}
