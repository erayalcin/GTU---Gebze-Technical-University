
public class q3 {
	/**
	 * @arr array
	 * @start array's start index
	 * @end array's end index
	 * @target sum of array's item
	 * 
	 */
	static void printSubArrays(int []arr, int start, int end,int target)
	{    
		
		/**
		 * base case
		 * Stop if we have reached the end of the array   
		 */  
	    if (end == arr.length)
	        return;
	    /**
	     * Recursive case
		 * Increment the end point and start from 0  
		 */ 
	    else if (start > end)
	        printSubArrays(arr, 0, end + 1,target);
	    /**
	     * Recursive case
		 * Print the subarray and increment the starting point  
		 */    
	    else
	    {
	    	  /**
			 * It collects the data between the start index and the end index and then checks 
			 * if it is equal to the target and if it is, it prints that start and end subarray to the screen
			 */
	    	
	    	
	        int checksum=0;
	        for (int i = start; i <= end; i++){
	        	checksum+=arr[i];
	        	
	        	
	        }
	        
	        if(checksum==target) 
	        {
	        	System.out.print("[");
	        	for (int i = start; i <= end; i++){
	        		if(i==end) System.out.print(arr[i]);
	        		else System.out.print(arr[i]+",");
		        	
		        	
		        }
	        	
	        	System.out.print("]");
	        }
	        
	        printSubArrays(arr, start + 1, end,target);
	    }
	     
	    return;
	}
	 
	public static void main(String args[])
	{
		
	 
	}

}
